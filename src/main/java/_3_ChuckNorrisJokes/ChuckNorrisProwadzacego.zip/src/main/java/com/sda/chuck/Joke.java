package com.sda.chuck;

public class Joke {
    public String value;

    public Joke() {
    }

}
