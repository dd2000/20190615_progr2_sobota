package com.detectlanguage.responses;

import com.detectlanguage.Result;

import java.util.List;

public class DetectionsData {
    public List<Result> detections;
}
