package com.detectlanguage.responses;

public class ErrorResponse extends Response {
    public ErrorData error;
}
