package com.detectlanguage.responses;

import com.detectlanguage.Result;

import java.util.List;

public class BatchDetectionsData {
    public List<List<Result>> detections;
}
