package com.detectlanguage;

public class Result {
    public String language;
    public boolean isReliable;
    public double confidence;
}
