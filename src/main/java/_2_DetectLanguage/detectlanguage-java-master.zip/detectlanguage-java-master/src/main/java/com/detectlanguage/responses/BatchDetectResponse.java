package com.detectlanguage.responses;

public class BatchDetectResponse extends Response {
    public BatchDetectionsData data;
}
