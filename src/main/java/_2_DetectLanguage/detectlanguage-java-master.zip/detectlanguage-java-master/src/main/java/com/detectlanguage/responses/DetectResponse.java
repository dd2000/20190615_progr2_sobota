package com.detectlanguage.responses;

public class DetectResponse extends Response {
    public DetectionsData data;
}
