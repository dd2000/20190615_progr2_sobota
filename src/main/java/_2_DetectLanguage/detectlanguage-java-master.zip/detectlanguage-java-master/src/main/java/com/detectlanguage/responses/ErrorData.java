package com.detectlanguage.responses;

public class ErrorData {
    public int code;
    public String message;
}
