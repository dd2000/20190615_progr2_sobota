package com.detectlanguage.responses;

abstract public class Response {
}
